# Data Modeling with Posgres Database for Sparkify Data Analytics team 
This project focused on creating postgres database for Sparkify data which was collected on songs and user activity on sparkify new music streaming app. Sparkify analytics team wants to understand users’ song preference and be able to query their data, which resides in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app. 


To design an optimized postgres database for sparkify data, database schema containing songsplay fact table was designed and integrated with users, songs, artists, and time dimension tables in python with python postgres wrapper. An ETL process and pipeline were built to extract, transform and load songs and artists data from songs dataset in JSON format, and users, time and songplays data from log_data dataset in a separate JSON data format.

## Database Schema and ETL pipeline design
 - Sql_queries.py file contains all the queries created to DROP tables, CREATE tables and INSERT records into the tables. The file is connected to create_tables.py file which when run, automatically execute all the queries in sql_queries. 
 - Create_tables.py file contains function procedures for DROP, CREATE AND INSERT queries, so when create_tables.py file is run, it automatically connects sql_queries.py file 
 - Test.ipynb file contains SQL queries that reads the created tables to test every process executed in etl.py file when records are inserted
 - Etl.ipynb file contains the function procedure that extract, transform and load all the records based on the verified ETL processes in etl.py file
 - README.md file contains detailed information about sparkify data analytics team objectives, how the progres database schema and ETL pipeline were designed 
 
## Running Schema and ETL pipeline design script files
To run the Schema and pipeline design files, do the following in the order of the list
- Ensure the query codes in sql_queries.py file are updated for any changes and properly saved
- Run the create_tables.py file – this can be done by typing the following on the python terminal > python create_tables.py and press enter
- Run etl.ipynb file – the etl process that was created to design and test processing a single record 
- Run test.ipynb file which contains queries to test the ETL process for loading a single record in each case of our schema tables
- Finally, run etl.py file which contains functions that load all the required records following the run with no error in the etl.ipynb and test.ipynb file
- Note – for any database connection error, ensure the KERNEL is restarted everytime test.ipynb files is executed.